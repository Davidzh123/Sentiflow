import React, { useEffect, useState } from 'react';
import { getTargets, askLlm } from '../services/api';

export default function AssistantLLM() {
  const [targets, setTargets] = useState([]);
  const [selectedTargets, setSelectedTargets] = useState([]);
  const [question, setQuestion] = useState('');
  const [days, setDays] = useState(7);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    loadTargets();
  }, []);

  const loadTargets = async () => {
    try {
      const response = await getTargets();
      setTargets(response.data);
    } catch (err) {
      setError("Impossible de charger les cibles.");
    }
  };

  const toggleTarget = (id) => {
    setSelectedTargets((current) =>
      current.includes(id)
        ? current.filter((targetId) => targetId !== id)
        : [...current, id]
    );
  };

  const handleAsk = async () => {
    if (!question.trim()) {
      setError("Pose une question.");
      return;
    }

    if (selectedTargets.length === 0) {
      setError("Sélectionne au moins une cible.");
      return;
    }

    setLoading(true);
    setError('');
    setResult(null);

    try {
      const response = await askLlm({
        question,
        target_ids: selectedTargets,
        days,
        generate_dashboard: true,
      });

      setResult(response.data);
    } catch (err) {
      setError(err.response?.data?.detail || "Erreur pendant l'appel au LLM.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page">
      <h1>Assistant LLM SentiFlow</h1>

      <p>
        Pose une question sur un ou plusieurs comptes / hashtags déjà collectés et analysés.
      </p>

      {error && <div className="error">{error}</div>}

      <div className="card">
        <h2>Cibles</h2>

        {targets.map((target) => (
          <label key={target.id} style={{ display: 'block', marginBottom: 8 }}>
            <input
              type="checkbox"
              checked={selectedTargets.includes(target.id)}
              onChange={() => toggleTarget(target.id)}
            />
            {' '}
            {target.name} ({target.target_type})
          </label>
        ))}
      </div>

      <div className="card">
        <h2>Question</h2>

        <textarea
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="Ex : Compare #Minecraft et #Fortnite sur les 7 derniers jours et génère un dashboard"
          rows={4}
          style={{ width: '100%' }}
        />

        <div style={{ marginTop: 12 }}>
          <label>
            Période :
            {' '}
            <input
              type="number"
              value={days}
              min="1"
              max="90"
              onChange={(e) => setDays(Number(e.target.value))}
            />
            {' '}
            jours
          </label>
        </div>

        <button onClick={handleAsk} disabled={loading} style={{ marginTop: 12 }}>
          {loading ? 'Analyse en cours...' : 'Demander au LLM'}
        </button>
      </div>

      {result && (
        <div className="card">
          <h2>Réponse</h2>

          <p style={{ whiteSpace: 'pre-line' }}>{result.answer}</p>

          <h3>Intention détectée</h3>
          <p>
            {result.intent} — confiance : {Math.round(result.intent_confidence * 100)}%
          </p>

          <h3>Dashboard généré</h3>
          <pre style={{ overflowX: 'auto' }}>
            {JSON.stringify(result.dashboard_config, null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
}